#!/bin/bash

echo "Checking for mounting at `date`" > /var/log/mounting_check.log
echo "Checking for mounting at `date`" > /var/log/mounting_check_error.log

for i in {1..3}
do
        total_mount=0

        >|/var/log/mounting_check.log
        >|/var/log/mounting_check_error.log
        echo "Checking for mounting at `date`" >> /var/log/mounting_check.log
        echo "Checking for mounting at `date`" >> /var/log/mounting_check_error.log
        echo "----------------------------------------" >> /var/log/mounting_check.log

        for mount_point in `cat /etc/fstab | awk '{print $1}' | grep -vE '#|swap|\/tmp|\/home' | grep '^/'`
        do
                is_mounted=0
                echo "checking for ${mount_point}" >> /var/log/mounting_check.log
                for mount_check in `mount -l | awk '{print $1}' | sort -u | grep '^/'`
                do
                        if [ ${mount_check} == ${mount_point} ]
                        then
                                is_mounted=1
                                total_mount=`expr $total_mount + 1`
                        fi
                done

                if [ $is_mounted -ne 1 ]
                then
                        echo "Mount point not available for ${mount_point}" >> /var/log/mounting_check.log
                        echo "Mount point not available for ${mount_point}" >>  /var/log/mounting_check_error.log
                        mount -a >> /var/log/mounting_check.log
                else
                        echo "Mount point available for ${mount_point}" >> /var/log/mounting_check.log
                fi

        done
        sleep 10
done

echo "Mount check completed at `date`" >> /var/log/mounting_check.log
echo "Mount check completed at `date`" >> /var/log/mounting_check_error.log

if [ `cat /etc/fstab | awk '{print $1}' | grep -vE '#|swap|\/tmp|\/home' | grep '^/' | wc -l` -ne ${total_mount} ]
then


    echo "Some mounts are not available please check mounting_check.log" >>/var/log/mounting_check.log

        echo "Some mounts are not available for $(uname -n) please check mounting_check.log. Server; $(curl http://169.254.169.254/latest/meta-data/local-ipv4)" | mutt -s "Mount point check for server; $(curl http://169.254.169.254/latest/meta-data/local-ipv4)" sistemasarqweb@libertyseguros.es lwemaws.in@capgemini.com -a /var/log/mounting_check_error.log

else

    echo "All mount are available" >> /var/log/mounting_check.log

fi

